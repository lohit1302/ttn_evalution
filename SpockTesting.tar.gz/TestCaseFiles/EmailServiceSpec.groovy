package demo

import demo.domain.Order
import demo.service.EmailService
import spock.lang.Specification

/**
 * Test Class for EmailService Class
 */

/**
 * Specification is a class which every class must extends for doing Spock testing
 */
class EmailServiceSpec extends Specification {
    //each def defines a feature
    def "Testing Singleton Design Pattern()"() {

        //in when we specify the stimulus here
        when: "EmailService object creation"
        def emailService1 = EmailService.getInstance()
        def emailService2 = EmailService.getInstance()

        //in then we check the response of the stimulus
        then:
        emailService1.hashCode() == emailService2.hashCode()
    }

    //each def defines a feature
    def "Testing sendEmail(Order order)"() {
        //setup phase
        given: "EmailService object creation"
        def emailService = EmailService.getInstance()
        def order = new Order(1, "Coke", 35.0);

        //in when we specify the stimulus here
        when:
        emailService.sendEmail(order)

        //in then we check the response of the stimulus
        then:
        //it tells that calling sendEmail method will pop an RunTime Exception
        thrown(RuntimeException)
    }

    //each def defines a feature
    def "Testing sendEmail(Order order,String cc)"() {
        //setup phase
        given: "EmailService object creation"
        def emailService = EmailService.getInstance()
        def order = new Order(1, "Coke", 35.0);

        //in when we specify the stimulus here
        when:
        boolean status = emailService.sendEmail(order, _ as String)

        //in then we check the response of the stimulus
        then:
        status == true
    }
}
