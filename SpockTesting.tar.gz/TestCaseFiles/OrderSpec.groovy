package demo

import demo.domain.Order
import spock.lang.Specification

/**
 * Specification is a class which every class must extends for doing Spock testing
 */
class OrderSpec extends Specification {

    //each def defines a feature
    def "Testing Getter and Setter Calling()"() {
        //setup phase
        given: "Order object creation"
        def order = new Order();

        //in when we specify the stimulus here
        when: "Setting values to the object"
        order.setItemName("Coke")
        order.setPrice(35.0)
        order.setQuantity(2)
        order.setPriceWithTex(70.0)

        //in then we check the response of the stimulus
        then:
        order.itemName == "Coke"
        order.price == 35.0
        order.quantity == 2
        order.priceWithTex == 70.0
    }

    //each def defines a feature
    def "Testing Parameterized Constructor()"() {
        //in when we specify the stimulus here
        when: "Order object creation and passing values using constructor"
        def order = new Order(2, "Coke", 35.0);

        //in then we check the response of the stimulus
        then:
        order.itemName == "Coke"
        order.price == 35
        order.quantity == 2
    }

    //each def defines a feature
    def "Testing Default Constructor()"() {
        //in when we specify the stimulus here
        when: "Order object creation"
        def order = new Order();

        //in then we check the response of the stimulus
        then:
        order.itemName == null
        order.price == 0.0
        order.quantity == 0
    }
}
