public class Question2 {
    public void duplicateElementsInAString(String input_string)
    {
        //splitting the word into string from spaces
        String string_array[]=input_string.split(" ");
        for (int i = 0; i < string_array.length; i++) {
            String word_to_be_checked=string_array[i];
            int count=0;
            if(word_to_be_checked.equals("*"))
                continue;
            for (int j = 0; j < string_array.length; j++) {
                if(word_to_be_checked.equals(string_array[j]))
                    count++;
            }
            if(count>1)
            {
                for (int j = 0; j <string_array.length ; j++) {
                    if(word_to_be_checked.equals(string_array[j]))
                        string_array[j]="*";
                }
                System.out.println("The input has the duplicate element="+word_to_be_checked+" number of times repeated="+--count);
            }
        }
    }

    public static void main(String[] args) {
        Question2 question2=new Question2();
        question2.duplicateElementsInAString("hello world world session session session");
    }
}
