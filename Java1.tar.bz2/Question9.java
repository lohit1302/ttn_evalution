public class Question9 {

    public static void main(String[] args) {
        System.out.println("All the houses price :");
        //loop to print all the values along with names of the house enum class
        for(House house : House.values())
        {
            System.out.println("House "+house+" cost "+house.getPrice());
        }
    }
}
//Creating a enum
enum House
{

    BHK1(200), BHK2(500), BHK3(1000);
    private int price;

    //Constructor of House
    House(int price) {
        this.price = price;
    }

    //method to get the details of enum
    public int getPrice() {
        return price;
    }
}