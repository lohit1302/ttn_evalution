public class Question1 {
    public String replaceString(String input_string,String to_be_replaced,String to_be_replace_with)
    {
        return input_string.replace(to_be_replaced,to_be_replace_with);
    }
    public static void main(String[] args) {
        Question1 question1=new Question1();
        //passing the string input_string,string to be replaced and with it is replaced to the method
        System.out.println(question1.replaceString("Hello People","People","Guys"));
    }
}
