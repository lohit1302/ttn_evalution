public class Question4 {
    public void percentageofOccurrenceofNumberSpecialCharacterLowerCaseAlphabetsandUpperCaseAlphabets(String input_string)
    {
        int special_character=0,lower_case_alphabets=0,upper_case_alphabets=0,numbers=0;
        for (int i = 0; i < input_string.length(); i++) {
            char character_in_string=input_string.charAt(i);
            //finding whether the selected character is a special character using the ascii code of it
            if((int)character_in_string >0 && (int)character_in_string <=47 || (int)character_in_string >=91 && (int)character_in_string <=96 || (int)character_in_string >=58 && (int)character_in_string <=64)
                special_character++;
            //finding whether the selected character is a upper case character using the ascii code of it
            else if((int)character_in_string >=65 && (int)character_in_string <=90)
                upper_case_alphabets++;
            //finding whether the selected character is a lower case character using the ascii code of it
            else if((int)character_in_string >=97 && (int)character_in_string <=122)
                lower_case_alphabets++;
            //finding whether the selected character is a number using the ascii code of it
            else if((int)character_in_string >=48 && (int)character_in_string <=57)
                numbers++;
        }
        //calculating the total length of the string
        double length_of_input_string=input_string.length();

        //calculating the percentage of uppercase,lowercase,digits,other characters*/
        double special_character_percentage=(special_character/length_of_input_string)*100,lower_case_alphabets_percentage=(lower_case_alphabets/length_of_input_string)*100,upper_case_alphabets_percentage=(upper_case_alphabets/length_of_input_string)*100,numbers_percentage=(
                numbers/length_of_input_string)*100;

        System.out.println("Percentage of Number in "+input_string+" = "+numbers_percentage);
        System.out.println("Percentage of Upper Case Alphabets in "+input_string+" = "+upper_case_alphabets_percentage);
        System.out.println("Percentage of Special Characters in "+input_string+" = "+special_character_percentage);
        System.out.println("Percentage of Lower Case Alphabets in "+input_string+" = "+lower_case_alphabets_percentage);
    }

    public static void main(String[] args) {
        Question4 question4=new Question4();
        question4.percentageofOccurrenceofNumberSpecialCharacterLowerCaseAlphabetsandUpperCaseAlphabets("1A@a");
    }
}
