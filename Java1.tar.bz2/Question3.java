import java.util.Scanner;

public class Question3 {
    public void count_number_of_occurrence_in_a_string(String input_string,char c)
    {
        System.out.println(input_string.length()-input_string.replace(String.valueOf(c),"").length());
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the string the character of which occurrence is to be found");
        String input=scanner.next();
        char character_to_searched=scanner.next().charAt(0);
        Question3 question3=new Question3();
        question3.count_number_of_occurrence_in_a_string(input,character_to_searched);
    }
}
