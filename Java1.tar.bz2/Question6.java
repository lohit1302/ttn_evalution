import java.util.Arrays;
import java.util.Collections;

public class Question6 {
    public void unrepeatedElement(int array[])
    {
        for (int i = 0; i < array.length; i++) {
            int count=0;
            for (int j = 0; j < array.length; j++) {
                if(array[i]==array[j])
                    count++;
            }
            if(count==1)
            {
                System.out.println("The Unique number in the list is "+array[i]);
                break;
            }
        }
    }

    public static void main(String[] args) {
        //Creating a object
        Question6 question6=new Question6();
        //Calling a method a passing the array
        question6.unrepeatedElement(new int[]{1,1,3,2,3,2,4,4,7});
    }
}
