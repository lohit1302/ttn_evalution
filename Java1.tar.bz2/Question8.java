public class Question8 {
    public void stringRemovefrom4to9PositionCharacter(StringBuffer string )
    {
        //reverse the string
        string.reverse();
        //delete the character from 4 to 9 position
        string.delete(4,9);
        System.out.println(string);
    }

    public static void main(String[] args) {
        Question8 question8=new Question8();
        question8.stringRemovefrom4to9PositionCharacter(new StringBuffer("abcdefghij"));
    }
}
