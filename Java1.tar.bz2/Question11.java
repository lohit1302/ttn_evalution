//Parent Class
class Bank
{
    float rate_of_interest=5.0f;
    void getDetails()
    {
        System.out.println("In a Bank");
        System.out.println("Rate of Interest " + rate_of_interest);
    }
}
//Chlid Class
class SBI extends Bank
{
    float rate_of_interest=4.0f;

    @Override
    void getDetails() {
        System.out.println("In a SBI Bank");
        System.out.println("Rate of Interest" + rate_of_interest);
    }
}
//Chlid Class
class ICICI extends Bank
{
    float rate_of_interest=2.0f;

    @Override
    void getDetails() {
        System.out.println("In a SBI Bank");
        System.out.println("Rate of Interest" + rate_of_interest);
    }
}
class BOI extends Bank
{
    float rate_of_interest=1.0f;

    @Override
    void getDetails() {
        System.out.println("In a BOI Bank");
        System.out.println("Rate of Interest" + rate_of_interest);
    }
}
public class Question11 {
    public static void main(String[] args) {
        //Parent Class Object
        Bank bank=new Bank();
        bank.getDetails();
        //Child Class Object
        SBI sbi=new SBI();
        sbi.getDetails();
        //Child Class Object
        BOI boi=new BOI();
        boi.getDetails();
    }
}
