public class Question5 {
    public void commonElementsInAArray(int array1[],int array2[])
    {
        /* Using two  loops to iterate the two arrays and compare the value of first array with all the values of other array*/
        for (int i = 0; i < array1.length; i++) {
            for (int j = 0; j < array2.length; j++) {
                if(array1[i]==array2[j]) {
                    System.out.println("Common Elements " + array1[i]);
                    break;
                }
            }
        }
    }

    public static void main(String[] args) {
        Question5 question5=new Question5();
        question5.commonElementsInAArray(new int[]{4,5,6},new int[]{3,4,5,6,8});
    }
}
