public class Question7 {
    static String first_name="Lohit";
    static String last_name="Ahooja";
    static int age=22;

    static
    {
        System.out.println("First Name "+first_name);
        System.out.println("Last Name "+last_name);
        System.out.println("Age "+age);
    }

    public static void details()
    {
        System.out.println("First Name "+first_name);
        System.out.println("Last Name "+last_name);
        System.out.println("Age "+age);
    }

    public static void main(String[] args) {
        //call static function
        details();

        //accessing static variable
        System.out.println("First Name "+Question7.first_name);
        System.out.println("Last Name "+Question7.last_name);
        System.out.println("Age "+Question7.age);
    }
}
