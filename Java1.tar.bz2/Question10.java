public class Question10 {

    //method overloading of add
    public int add(int number1, int number2) {
        return number1 + number2;
    }

    //method overloading of add
    public double add(double number1, double number2) {
        return number1 + number2;
    }

    //method overloading of multiply
    public int multiply(int number1, int number2) {
        return number1 * number2;
    }

    //method overloading of multiply
    public double multiply(float number1, float number2) {
        return number1 * number2;
    }

    //method overloading of concat
    public String concat(String string1, String string2) {
        return string1.concat(string2);
    }

    //method overloading of concat
    public String concat(String string1, String string2, String string3) {
        return string3.concat(string1.concat(string2));
    }

    public static void main(String[] args) {
        Question10 question10=new Question10();
        //Calling method with 2 integers as parameters and printing their sum
        System.out.println("Adding two integers "+question10.add(1,2));
        //Calling method with 2 double as parameters and printing their sum
        System.out.println("Adding two double "+question10.add(1.0d,2.0d));
        //Calling method with 2 integers as parameters and printing their multiplication
        System.out.println("multiply two integers "+question10.multiply(1,2));
        //Calling method with 2 float as parameters and printing their multiplication
        System.out.println("multiply two float "+question10.multiply(1.0f,2.0f));
        //Calling method with 2 strings as argument and printing their concate
        System.out.println("Concat two String "+question10.concat("Hello","Guys"));
        //Calling method with 3 strings as argument and printing their concate
        System.out.println("Adding three String "+question10.concat("How are you?","Hello","Guys"));
    }
}
